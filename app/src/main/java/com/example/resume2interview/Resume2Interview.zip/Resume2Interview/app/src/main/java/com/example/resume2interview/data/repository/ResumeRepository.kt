package com.example.resume2interview.data.repository

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ResumeRepository @Inject constructor() {
    // Suspend functions for resume upload, extraction
}
