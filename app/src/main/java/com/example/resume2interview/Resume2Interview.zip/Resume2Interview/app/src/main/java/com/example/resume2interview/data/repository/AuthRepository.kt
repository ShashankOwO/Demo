package com.example.resume2interview.data.repository

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor() {
    // Suspend functions for login, signup, etc.
}
