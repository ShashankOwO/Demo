package com.example.resume2interview.data.repository

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InterviewRepository @Inject constructor() {
    // Suspend functions for interview sessions, reports
}
